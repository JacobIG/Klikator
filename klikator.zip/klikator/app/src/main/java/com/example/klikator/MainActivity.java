package com.example.klikator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView time, click;
    Button btn_click, btn_start,btn_exit;

    CountDownTimer timer;

    int t=30;
    int c=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        time = (TextView)findViewById(R.id.time);
        click = (TextView)findViewById(R.id.click);
        btn_click = (Button)findViewById(R.id.btn_click);
        btn_start = (Button)findViewById(R.id.btn_start);
        btn_exit = (Button)findViewById(R.id.btn_exit);

        btn_start.setEnabled(true);
        btn_click.setEnabled(false);


        timer = new CountDownTimer(10000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                t--;
                time.setText("Czas : " + t);
            }

            @Override
            public void onFinish() {
                btn_start.setEnabled(true);
                btn_click.setEnabled(false);
                time.setText("Czas : 0");

            }
        };

        btn_click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                c++;
                click.setText("Kliknij : " + c);
            }
        });

        btn_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                timer.start();
                btn_start.setEnabled(false);
                btn_click.setEnabled(true);
                c=0;
                t=10;
                time.setText("Czas : " + t);
                click.setText("Kliknij : " + c);
            }
        });

        btn_exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                moveTaskToBack(true);
                android.os.Process.killProcess(android.os.Process.myPid());
                System.exit(1);
            }
        });



    }
}